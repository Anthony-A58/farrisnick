# Farris Law Firm — Build & WordPress Handoff

## What's in this project

**Design source (live, interactive previews):**
- `Farris Homepage Directions.dc.html` — the 3 original homepage concepts
- `Farris Home.dc.html` — full Blackout homepage
- `Farris About.dc.html`, `Farris Practice Areas.dc.html`, `Farris Results.dc.html`,
  `Farris Blog.dc.html`, `Farris FAQ.dc.html`, `Farris Testimonials.dc.html`, `Farris Contact.dc.html`

**Production build (hand off to WordPress / test in Lighthouse):**
- `dist/index.html` — minified, framework-free, SEO- and Lighthouse-optimized homepage.
  This is the reusable pattern; the other pages follow the same head/CSS/header/footer.

The design files use a live-preview runtime and are for *reviewing and iterating on the design*.
The `dist/` file is clean static HTML you actually ship.

## Design system (keep consistent everywhere)
- Colors: black `#0a0a0a` / `#141414`, yellow accent `#eab308`, greys `#a1a1aa` `#71717a`, white `#fff`
- Fonts: **Anton** (display headlines, uppercase) + **Archivo** (body, 400–900)
- Signature effect: video-in-cutout-letters hero bands (see below)

## The video-in-letters effect (Lassiter-style)
`dist/index.html` ships it with `background-clip:text` over an animated gradient — zero JS, paints
instantly, safe for Lighthouse. To play a real video *through* the letters, layer an SVG `<mask>`
(white rect + black `<text>`) over a `<video>` — ask me and I'll wire it. Either way:
- Use a short (<10s), muted, compressed clip: H.264 MP4 + WebM, target < 2 MB.
- `preload="none"` + a lightweight `poster` image keeps video off the critical path.
- Provide a static poster so the section looks right before/without video (and on mobile data-saver).

## Placeholders to replace
Every striped box marked `VIDEO / IMAGE · …`, `PORTRAIT · …`, `GOOGLE MAP · …`, or `POST IMAGE`
is a drop-in slot. Replace with real, compressed assets and add descriptive `alt` text (SEO + a11y).

## SEO checklist (you're optimizing these keywords)
Targets: *dui attorneys in orange county / los angeles county*, *criminal defense lawyer orange
county / los angeles county*.
- One `<h1>` per page (homepage's is in `.sr` visually-hidden so the cutout art can be decorative).
- Keyword-rich `<title>` + meta description per page (see `dist/index.html` head — clone & edit).
- `LegalService` JSON-LD schema is in the head — fill in real addresses, geo, hours, review count.
- Replace lorem ipsum with your optimized copy; keep the H2/H3 keyword structure.
- Add per-page canonical URLs, an XML sitemap, and unique OG tags.
- FAQ uses native `<details>` — pair it with `FAQPage` JSON-LD for rich results.

## Lighthouse / performance (already handled in dist/)
- Critical CSS inlined in `<style>` → no render-blocking stylesheet request.
- `font-display:swap` + `preconnect` to Google Fonts (self-host the two fonts to go further).
- Near-zero JS (FAQ is CSS-only `<details>`), semantic landmarks, responsive `@media` rules.
- Still to do on the server/build: enable **gzip/Brotli**, cache headers, and run the HTML/CSS
  through a minifier in your build step (the dist file is already compact; a minifier squeezes more).
- Convert images to **WebP/AVIF**, set explicit width/height to avoid layout shift (CLS), `loading="lazy"`.

## Porting to WordPress
Recommended: a lightweight custom block theme (or a fast builder if the client will self-edit).
1. Map each page to a WordPress **template**: `front-page`, `page-about`, `archive` (blog), etc.
2. Move the `<style>` block to the theme's stylesheet (enqueue it), or keep critical CSS inlined.
3. Turn the practice-area cards, results, testimonials, and FAQ into **repeatable fields**
   (ACF / block patterns) so the client edits content without touching markup.
4. Wire the contact form to a real plugin (e.g. a form plugin) — the dist markup is the visual only.
5. Use a caching + optimization plugin for gzip/Brotli, asset minification, and lazy-loading.

## Nav / file map (dist → WordPress pages)
index · about · practice-areas · results · blog · testimonials · faq · contact
(The design `.dc.html` files link with the same names, URL-encoded.)
